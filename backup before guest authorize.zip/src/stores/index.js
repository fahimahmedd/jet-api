// Utilities
import { createPinia } from 'pinia'

export default createPinia()
