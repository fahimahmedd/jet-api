<script setup></script>

<template>
  <div class="common-section">
    <v-container>
      <v-row class="d-flex align-center">
        <v-col cols="12" lg="6" md="7">
          <div class="feature-content">
            <h2 class="text-grey-darken-1">Interested in private charters?</h2>
            <h2>Fly anywhere, anytime</h2>
            <p class="font-weight-light text-black mt-3">
                In addition to our ongoing scheduled routes, Aero also offers private charter bookings. Fly with flexibility, convenience and ease, and enjoy our unparalleled service from the comfort of your own jet.
            </p>
          </div>
        </v-col>
      </v-row>
    </v-container>
  </div>
</template>

<style scoped>
.common-section{
    padding: 100px 0;
}
.feature-content h2 {
  font-size: 38px;
  font-weight: 400;
}
.feature-content p {
  font-size: 16px;
}
.booking-btn{
    background-color: #000;
    font-weight: 700;
    color: #fff;
}
.common-section{
    background-color: #f3f3f3;
}
</style>
