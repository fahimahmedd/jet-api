<script setup></script>

<template>
  <div class="text-caption-1 text-grey-darken-2 font-weight-regular mt-10">
    Have a coupon code?
  </div>
  <v-text-field
    density="comfortable"
    label="Apply Coupon Code"
    variant="tonal"
    hide-details
    single-line
    bg-color="#f3f3f3"
    class="mt-3"
    append-inner-icon="mdi-arrow-right"
    max-width="320"
    rounded="lg"
  ></v-text-field>
</template>

<style scoped></style>
